"use strict";

function notifying() {
	BG.isNotify && ($("button#notify").html("取消通知"), $("#notify-counter").html(BG.refreshCouter), $("#notify-last-time").html($.date("Y-m-d H:i", BG.lastQueryTime)), $("#notify-process").show())
}
function setNotifyConfig() {
	var a = $.trim($("#account").val()),
		b = $.trim($("#password").val()),
		c = $.trim($("#mobile").val());
	if (!a || !b) return alert("账号密码不可为空！");
	if (!/1\d{10}/.test(c)) return alert("手机号不合法！");
	var d = {
		account: a,
		password: b,
		mobile: c
	};
	return port.postMessage({
		req: "setStorage",
		data: {
			notifyConfig: d
		}
	}), !0
}
function toggleNotify() {
	BG.isNotify = !BG.isNotify, $("button#notify").html(BG.isNotify ? "取消通知" : "短信通知"), notifying(), port.postMessage({
		req: BG.isNotify ? "refreshState-start" : "refreshState-stop"
	})
}
var port = chrome.runtime.connect({
	name: "popup"
}),
	BG = chrome.extension.getBackgroundPage();
$.extend({
	date: function(a, b) {
		var c = b ? new Date(b) : new Date,
			d = function(a) {
				return 10 > a ? "0" + a : a
			};
		return a.replace(/[YmdHis]/g, function(a) {
			switch (a) {
			case "Y":
				return c.getFullYear();
			case "m":
				return d(c.getMonth() + 1);
			case "d":
				return d(c.getDate());
			case "H":
				return d(c.getHours());
			case "i":
				return d(c.getMinutes());
			case "s":
				return d(c.getSeconds())
			}
		})
	}
}), $(document).ready(function() {
	notifying(), port.postMessage({
		req: "getStorage",
		key: ["notifyConfig"]
	}), port.onMessage.addListener(function(a) {
		if (a.data.notifyConfig) {
			var b = a.data.notifyConfig;
			$("#account").val(b.account), $("#password").val(b.password), $("#mobile").val(b.mobile), $("#notify-config").data("done", !0)
		}
		a.alert && alert(a.msg)
	})
}), $("button#analyze").on("click", function() {
	port.postMessage({
		target: "content",
		req: "analyze"
	}), port.onMessage.addListener(function(a) {
		if ("undefined" == typeof a.analyze) return !1;
		$("#apply-status").html(a.status || "");
		/*var b = a.passData;
		if (b && b.length) {
			for (var c = "", d = 0; d < b.length; d++) c = "<tr>", c += "<td>" + b[d].stage + "</td>", c += "<td>第" + b[d].round + "轮</td>", c += "<td>" + b[d].isPass + "</td>", c += "</tr>";
			c = c || '<tr><td colspan="3">暂无面试状态</td></tr>', $("#interview-process").html(c)
		}*/
		$("#result").show()
	})
}), $(".open-link").on("click", function() {
	chrome.tabs.create({
		url: $(this).data("url")
	})
}), $("button#notify").on("click", function() {
	!BG.isNotify && $("#notify-config").show(), BG.isNotify && toggleNotify()
}), $("button#test-notify-config").on("click", function() {
	setNotifyConfig(), port.postMessage({
		req: "testNotify"
	})
}), $("button#confim-notify-config").on("click", function() {
	setNotifyConfig() && ($("#notify-config").data("done", !0), $("#notify-config").hide(), BG.isNotify || toggleNotify())
});